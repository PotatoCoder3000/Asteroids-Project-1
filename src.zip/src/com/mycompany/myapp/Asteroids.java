package com.mycompany.myapp;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;

public class Asteroids extends MovableObj {
	private int size;
	private int color;
	private int speed;
	private int direction;
	private Location location = new Location(r.nextInt(1024),r.nextInt(768));
	
	public Asteroids() {
		super();
		this.size = 10+r.nextInt(20);
	} 
	
	public Asteroids(Location location, int color, int speed, int direction){
		super(location, color, speed, direction);
		this.size = 10 + r.nextInt(20);
	}
	
	public void setSize(int size) {
		this.size = size;
	}
	
	public int getSize() {
		return size;
	}
	
	public String toString() {
		return "Asteroid: " + super.toString() + " Size: " + getSize();
	}

}
