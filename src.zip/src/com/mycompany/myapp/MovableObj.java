package com.mycompany.myapp;


public abstract class MovableObj extends GameObjects{
	
	private int direction;
	private int speed;
	private int missles;
	private int size;
	private int fuel;
	
	public MovableObj(){
		super();
		direction = (r.nextInt(359));
		speed = (r.nextInt(10));
	}
	
	public MovableObj(Location location, int color,  int direction, int speed) {
		super(location, color);
		this.direction = direction;
		this.speed = speed;
	}
	
	public void setDirection(int direction) {
		this.direction = direction;
	}
	
	public int getDirection() {
		return direction;
	}
	
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	public int getSpeed() {
		return speed;
	}
	
	public void setMissles(int missles) {
		this.missles = missles;
	}
	
	public int getMissles() {
		return missles;
	}
	
	public String toString(){
			
		return super.toString() + " Direction= " + getDirection() +" Speed= " +getSpeed();
		}
}
