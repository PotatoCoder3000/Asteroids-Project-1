package com.mycompany.myapp;

import java.util.*;
import java.util.Iterator;
import java.util.Collection;

import com.codename1.charts.util.ColorUtil;

public class GameWorld {
	GameObjectCollections Objects = new GameObjectCollections();
	Random r = new Random();
	private int lives;
	private int clock;
	private int missles;
	private int fuel;
	private Location shipPoint = new Location(512,384);
	private Location aLocation;
	private Location bLocation;
	private Ship ship;
	
	//private Vector<GameObjects> Objects = new Vector<GameObjects>();
	
	public void init() {
		clock = 0;
		lives = 3;
		missles = 10;
		fuel = 10;
	}
	
	public void newAsteroid(){
		aLocation = new Location(r.nextInt(1024),r.nextInt(768));
		Objects.add(new Asteroids(aLocation, ColorUtil.rgb(255, 0, 0), r.nextInt(359), r.nextInt(10)));
	}
	
	public void newStation(){
		bLocation = new Location(r.nextInt(1024),r.nextInt(768));
		Objects.add(new SpaceStation(bLocation, ColorUtil.rgb(0, 0, 255)));
	}
	
	public void newShip(){
		Objects.add(new Ship(shipPoint, ColorUtil.rgb(0,255,0), 90, 0));
	}
	
	public void shipAccelerate(){
		ship.accelerate();
	}
	
	public void shipDecelerate(){
		ship.decelerate();
	}
	
	public void shipLeft(){
		ship.steerLeft();
	}
	
	public void shipRight(){
		ship.steerRight();
	}
	
	public void fire(){
		ship.fireMissle();
	}
	
	public String printTextMap(){
		
		Iterator<GameObjects> iterator = Objects.getIterator();
		String map = "";
		String newLine = "\n";
		while (iterator.hasNext()) {
			GameObjects item = iterator.next();
			map = map + item.toString() +newLine;
		}
		return map;
	}
}
