package com.mycompany.myapp;
import java.util.Vector;
import java.util.Iterator;


//created a objects collection
public class GameObjectCollections{
	
	//using past csc20 assignment deque20 and TTTgame to work on this Iterator/Collections
	private Vector<GameObjects> gameObjectCollections ;
	
    public GameObjectCollections(){
    	gameObjectCollections = new Vector<GameObjects>();
    }
    
    public int size(){
    	return gameObjectCollections.size();
    }
    
    public Iterator<GameObjects> getIterator(){
        return new GameObjectIterator();
    }
    
    public void add(GameObjects newObject){
    	gameObjectCollections.addElement(newObject);
    }
    
    public void remove(GameObjects oldObject){
    	gameObjectCollections.remove(oldObject);
    }
    
    private class GameObjectIterator implements Iterator<GameObjects>{
        
    	private int currentElementIndex;
        
        public GameObjectIterator(){
          currentElementIndex = -1;
        }
        
        public boolean hasNext() {
            if (gameObjectCollections.size()<= 0){
            	return false;
            }
            if (currentElementIndex == gameObjectCollections.size()-1 ){
              return false;
            }
            return true;
        }
        
        public GameObjects next(){
            currentElementIndex ++ ;
            return(gameObjectCollections.elementAt(currentElementIndex));
        }

		public void remove() {
			
		}

    }
	
}
