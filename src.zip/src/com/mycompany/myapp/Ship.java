package com.mycompany.myapp;

import com.codename1.charts.util.ColorUtil;

public class Ship extends MovableObj implements ISteerable {
	private int missles;
	private int direction;
	private Location location;
	private int color;
	
	public Ship(){
		super();
	}
	
	public Ship(Location location, int color, int speed, int direction){
		super(location, color, speed, direction);
		missles = 10;
		
	}
	
	public void setSpeed(int speed){
		super.setSpeed(speed);
	}
	
	public void accelerate(){
		setSpeed(getSpeed() + 2);
	}
	
	public void decelerate() {
		if (getSpeed() > 2)
			setSpeed(getSpeed() - 2);
		else if (getSpeed() <= 2)
			setSpeed(0);
	}
	
	//set missles
	public void setMissles(int missles) {
		this.missles = missles;
	}
	
	//get missles
	public int getMissles() {
		return missles;
	}
	
	public void fireMissle() {
		missles = missles - 1;
	}
	
	//steer left
	public void steerLeft(){
		if(direction > (4 - 40) )
			direction = direction - 5;
		}
	
	//steer right
	public void steerRight(){
		if( direction < (40 - 4) )
			direction = direction + 5;
	}
	
	
	//toString
	public String toString(){
		return " Ship: " + super.toString() + " Missles: " + getMissles();
	}

}
